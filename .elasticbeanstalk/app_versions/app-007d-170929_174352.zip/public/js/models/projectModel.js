ProjectModel = Backbone.Model.extend({

  defaults : {
    id : '',
    title : '',
    icon : '',
    description_en : '',
    description_fr : '',
    icons: '',
    img : '',
    video : '',
    category : '',
    template : ''
  }

});
